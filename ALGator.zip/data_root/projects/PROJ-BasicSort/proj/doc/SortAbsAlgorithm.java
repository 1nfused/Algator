public abstract class SortAbsAlgorithm {
  protected abstract void execute(int [] data);
}
